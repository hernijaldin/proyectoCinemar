package prueba_basedatos;
import java.sql.*;
public class conexion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
			
			
			Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_cinemar", "root", "");
			
			Statement miStatemet = miConexion.createStatement();
			
			String sql = "select * from peliculas;";
			
			ResultSet miResulset = miStatemet.executeQuery(sql);
			
			while(miResulset.next() != false) {  
				System.out.println(miResulset.getString("genero") +" " + miResulset.getString("salas") + " " + miResulset.getString("titulo"));  //le pasamos el nombre de la columna de la tabla que queremos que nos devuelva	
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}

	}



