package prueba_basedatos;
import java.sql.*;
public class conexion2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
			
			
			Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_cinemar", "root", "");
			
			Statement miStatemet = miConexion.createStatement();
			
			String sql = "select * from funciones;";
			
			ResultSet miResulset = miStatemet.executeQuery(sql);
			
			while(miResulset.next() != false) {  
				System.out.println(miResulset.getInt("id_funcion") +" " + miResulset.getInt("id_prog") + " " + miResulset.getInt("id_sala") + " " + miResulset.getString("est_fun"));  //le pasamos el nombre de la columna de la tabla que queremos que nos devuelva	
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}

	}
